import pkg from "pg";
const { Pool } = pkg;

const requiredEnv = ["DB_HOST", "DB_PORT", "DB_USER", "DB_PASSWORD", "DB_NAME"];
const missing = requiredEnv.filter(key => !process.env[key]);

let pool = null;
export const dbEnabled = missing.length === 0;

if (!dbEnabled) {
    console.warn(
        `Database connections disabled: missing ${missing.join(", ") || "required env"}`
    );
} else {
    pool = new Pool({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME,
        ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
    });

    pool.on("connect", () => {
        console.log("Connected to the database");
    });

    pool.on("error", err => {
        console.error("Database connection error:", err);
        process.exit(1);
    });
}

export default pool;
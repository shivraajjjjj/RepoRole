import crypto from 'crypto';

export function generateCacheKey(repoUrl) {
    return crypto.createHash('sha256').update(repoUrl).digest('hex');
}
import pool, { dbEnabled } from "../config/db.js";
import { generateCacheKey } from '../utils/cacheKey.js';

let warnedNoDb = false;
const ensureDb = () => {
    if (dbEnabled && pool) return true;
    if (!warnedNoDb) {
        console.warn("DB caching disabled (no database configured)");
        warnedNoDb = true;
    }
    return false;
};

export async function getCached(repoUrl) {
    if (!ensureDb()) return null;
    const cacheKey = generateCacheKey(repoUrl);

    const result = await pool.query(
        `SELECT data
        FROM repo_cache
        WHERE cache_key = $1
        AND expires_at > NOW()`,
        [cacheKey]
    );

    if (result.rows.length === 0) {
        return null;
    }
    return result.rows[0].data;
}

export async function setCache(repoUrl,owner,repo,data) {
    if (!ensureDb()) return;
    console.log("Setting cache for ",repoUrl);
    if(!data){
        throw new Error("Refused to cache empty data");
    }
    try{
    const cacheKey = generateCacheKey(repoUrl);

    await pool.query(
        `CREATE TABLE IF NOT EXISTS repo_cache (
            cache_key TEXT PRIMARY KEY,     
            repo_url TEXT NOT NULL,
            owner TEXT NOT NULL,
            repo TEXT NOT NULL,

            data JSONB NOT NULL,    
            fetched_at TIMESTAMPTZ NOT NULL,
            expires_at TIMESTAMPTZ NOT NULL
        )`  
    );

    await pool.query(
        `INSERT INTO repo_cache 
        (repo_url,cache_key, owner, repo, data, fetched_at, expires_at)
        VALUES ($1, $2, $3, $4, $5, NOW(), NOW() + INTERVAL '24 hour')
        ON CONFLICT (cache_key)
        DO UPDATE SET 
    data = EXCLUDED.data,
     fetched_at = NOW(), 
     expires_at = NOW() + INTERVAL '24 hour'`,

     [repoUrl, cacheKey, owner, repo, data]
    );
}catch(err){
    console.log("Failed to set cache: ",err.message);
};
console.log("cache inserted for ",repoUrl);
}